/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Sun,
  CloudSun,
  Cloud,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudSnow,
  CloudLightning,
  Moon,
  CloudMoon,
  type LucideIcon,
} from 'lucide-react';

export interface WeatherCondition {
  label: string;
  icon: LucideIcon;
  themeClass: string; // Dynamic tailwind class representing this weather state
  bgGradient: string; // Screen-wide dynamic gradient
  textTheme: string;
  iconColor: string;
}

export function getWeatherCondition(code: number, isDay: boolean = true): WeatherCondition {
  // WMO Weather interpretation codes (WW)
  // https://open-meteo.com/en/docs
  switch (code) {
    case 0: // Clear sky
      return {
        label: isDay ? 'Clear Sky' : 'Clear Night',
        icon: isDay ? Sun : Moon,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-amber-100 via-orange-100 to-yellow-50 text-amber-900 shadow-amber-100/50' 
          : 'bg-gradient-to-br from-slate-900 via-indigo-950 to-neutral-950 text-slate-100 shadow-slate-900/40',
        bgGradient: isDay 
          ? 'from-sky-300 via-amber-100 to-orange-50' 
          : 'from-slate-950 via-slate-900 to-indigo-950',
        textTheme: isDay ? 'text-amber-950' : 'text-slate-100',
        iconColor: isDay ? 'text-amber-500 fill-amber-500/20' : 'text-slate-300 fill-slate-300/10',
      };
    case 1: // Mainly clear
    case 2: // Partly cloudy
      return {
        label: isDay ? 'Partly Cloudy' : 'Partly Cloudy Night',
        icon: isDay ? CloudSun : CloudMoon,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-sky-50 via-blue-50 to-amber-50 text-blue-900 shadow-blue-100/50' 
          : 'bg-gradient-to-br from-zinc-900 via-slate-900 to-zinc-950 text-slate-200 shadow-zinc-950/40',
        bgGradient: isDay 
          ? 'from-sky-200 via-blue-50 to-amber-50' 
          : 'from-zinc-950 via-slate-950 to-zinc-900',
        textTheme: isDay ? 'text-sky-950' : 'text-slate-200',
        iconColor: isDay ? 'text-sky-500' : 'text-indigo-400',
      };
    case 3: // Overcast
      return {
        label: 'Overcast',
        icon: Cloud,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-slate-100 via-zinc-100 to-stone-50 text-slate-800 shadow-slate-200/50' 
          : 'bg-gradient-to-br from-stone-900 via-zinc-900 to-neutral-950 text-zinc-300 shadow-stone-950/40',
        bgGradient: isDay 
          ? 'from-slate-300 via-zinc-200 to-slate-100' 
          : 'from-stone-950 via-zinc-950 to-neutral-950',
        textTheme: isDay ? 'text-slate-900' : 'text-zinc-200',
        iconColor: 'text-slate-400',
      };
    case 45: // Fog
    case 48: // Depositing rime fog
      return {
        label: 'Foggy',
        icon: CloudFog,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-stone-100 via-neutral-100 to-slate-50 text-stone-800 shadow-stone-100/50' 
          : 'bg-gradient-to-br from-neutral-900 via-neutral-950 to-stone-950 text-neutral-300 shadow-neutral-950/50',
        bgGradient: isDay 
          ? 'from-neutral-300 via-stone-200 to-stone-100' 
          : 'from-neutral-950 via-stone-950 to-neutral-900',
        textTheme: isDay ? 'text-neutral-900' : 'text-neutral-200',
        iconColor: 'text-stone-400',
      };
    case 51: // Light drizzle
    case 53: // Moderate drizzle
    case 55: // Dense drizzle
    case 56: // Light freezing drizzle
    case 57: // Dense freezing drizzle
      return {
        label: 'Drizzle',
        icon: CloudDrizzle,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-sky-50 via-slate-100 to-teal-50 text-slate-800 shadow-sky-100/40' 
          : 'bg-gradient-to-br from-slate-950 via-zinc-900 to-indigo-950 text-slate-300 shadow-zinc-950/40',
        bgGradient: isDay 
          ? 'from-sky-200 via-slate-100 to-teal-100' 
          : 'from-slate-950 via-neutral-950 to-slate-900',
        textTheme: isDay ? 'text-teal-950' : 'text-slate-200',
        iconColor: 'text-sky-400',
      };
    case 61: // Slight rain
    case 63: // Moderate rain
    case 65: // Heavy rain
    case 66: // Light freezing rain
    case 67: // Heavy freezing rain
    case 80: // Slight rain showers
    case 81: // Moderate rain showers
    case 82: // Violent rain showers
      return {
        label: 'Rainy',
        icon: CloudRain,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-blue-50 via-sky-100 to-indigo-50 text-blue-900 shadow-indigo-100/40'
          : 'bg-gradient-to-br from-indigo-950 via-slate-900 to-zinc-950 text-slate-200 shadow-indigo-950/40',
        bgGradient: isDay 
          ? 'from-indigo-300 via-sky-200 to-slate-200' 
          : 'from-neutral-950 via-indigo-950 to-slate-950',
        textTheme: isDay ? 'text-blue-950' : 'text-indigo-200',
        iconColor: 'text-blue-500 fill-blue-500/10',
      };
    case 71: // Slight snow fall
    case 73: // Moderate snow fall
    case 75: // Heavy snow fall
    case 77: // Snow grains
    case 85: // Slight snow showers
    case 86: // Heavy snow showers
      return {
        label: 'Snowy',
        icon: CloudSnow,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-sky-50 via-neutral-50 to-blue-50 text-slate-800 shadow-sky-50/50' 
          : 'bg-gradient-to-br from-indigo-950 via-slate-900 to-neutral-900 text-sky-100 shadow-sky-950/40',
        bgGradient: isDay 
          ? 'from-blue-200 via-slate-105 to-sky-100' 
          : 'from-slate-950 via-zinc-900 to-indigo-950',
        textTheme: isDay ? 'text-stone-900' : 'text-slate-200',
        iconColor: 'text-sky-300',
      };
    case 95: // Thunderstorm: Slight or moderate
    case 96: // Thunderstorm with slight hail
    case 99: // Thunderstorm with heavy hail
      return {
        label: 'Thunderstorm',
        icon: CloudLightning,
        themeClass: isDay 
          ? 'bg-gradient-to-br from-slate-200 via-indigo-100 to-zinc-200 text-indigo-950 shadow-indigo-200/50' 
          : 'bg-gradient-to-br from-indigo-950 via-indigo-950 to-stone-950 text-indigo-200 shadow-indigo-950/60',
        bgGradient: isDay 
          ? 'from-slate-400 via-zinc-300 to-indigo-300' 
          : 'from-black via-slate-950 to-indigo-950',
        textTheme: isDay ? 'text-indigo-950' : 'text-slate-100',
        iconColor: 'text-amber-500 animate-pulse',
      };
    default:
      return {
        label: 'Clear Sky',
        icon: Sun,
        themeClass: 'bg-gradient-to-br from-amber-50 to-orange-105 text-amber-900',
        bgGradient: 'from-sky-300 via-amber-100 to-orange-50',
        textTheme: 'text-amber-950',
        iconColor: 'text-amber-500',
      };
  }
}

/**
 * Formats a date string (ISO) into a readable format
 */
export function formatDate(isoString: string): string {
  try {
    const date = new Date(isoString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return isoString;
  }
}

/**
 * Formats a date string into just a weekday name (e.g. Wednesday)
 */
export function formatDayName(isoString: string): string {
  try {
    const date = new Date(isoString);
    const today = new Date();
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    }
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  } catch {
    return 'Day';
  }
}

/**
 * Strips the date part from a datetime string to display hours, e.g. "14:00" or "2:00 PM"
 */
export function formatHour(dateTimeStr: string): string {
  try {
    const date = new Date(dateTimeStr);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return dateTimeStr;
  }
}

/**
 * Get wind direction cardinal label from degrees
 */
export function getWindDirection(deg: number): string {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const index = Math.floor(((deg + 11.25) % 360) / 22.5);
  return directions[index] || 'N';
}

/**
 * Formats UV index into level descriptions
 */
export function getUvIndexDescription(uv: number): { label: string; color: string } {
  if (uv <= 2) return { label: 'Low', color: 'text-emerald-500 bg-emerald-500/10' };
  if (uv <= 5) return { label: 'Moderate', color: 'text-yellow-600 bg-yellow-500/10' };
  if (uv <= 7) return { label: 'High', color: 'text-orange-500 bg-orange-500/10' };
  if (uv <= 10) return { label: 'Very High', color: 'text-red-500 bg-red-500/10' };
  return { label: 'Extreme', color: 'text-purple-500 bg-purple-500/10' };
}
