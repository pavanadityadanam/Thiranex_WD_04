/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, Loader2, X, Star } from 'lucide-react';
import { GeocodingResult, SavedLocation } from '../types';

interface CitySearchProps {
  onSelectCity: (city: GeocodingResult) => void;
  savedLocations: SavedLocation[];
  onToggleSaveLocation: (city: GeocodingResult | SavedLocation) => void;
  currentCity: GeocodingResult | null;
}

export default function CitySearch({
  onSelectCity,
  savedLocations,
  onToggleSaveLocation,
  currentCity,
}: CitySearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GeocodingResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Default quick select locations
  const popularCities: SavedLocation[] = [
    { id: 'london', name: 'London', country: 'United Kingdom', latitude: 51.50853, longitude: -0.12574, timezone: 'Europe/London' },
    { id: 'new-york', name: 'New York', country: 'United States', latitude: 40.71427, longitude: -74.00597, timezone: 'America/New_York' },
    { id: 'tokyo', name: 'Tokyo', country: 'Japan', latitude: 35.6895, longitude: 139.69171, timezone: 'Asia/Tokyo' },
    { id: 'sydney', name: 'Sydney', country: 'Australia', latitude: -33.86785, longitude: 151.20732, timezone: 'Australia/Sydney' },
    { id: 'paris', name: 'Paris', country: 'France', latitude: 48.85341, longitude: 2.3488, timezone: 'Europe/Paris' },
  ];

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Fetch results when query is submitted or is being typed
  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    setErrorMessage(null);
    setIsOpen(true);

    try {
      const response = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
          searchQuery
        )}&count=6&language=en&format=json`
      );

      if (!response.ok) {
        throw new Error('Network error. Failed to reach search service.');
      }

      const data = await response.json();
      if (data.results && data.results.length > 0) {
        setResults(data.results);
      } else {
        setResults([]);
        setErrorMessage(`No cities found matching "${searchQuery}"`);
      }
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : 'An error occurred while searching.');
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(query);
  };

  const handleClear = () => {
    setQuery('');
    setResults([]);
    setErrorMessage(null);
    setIsOpen(false);
  };

  const isSaved = (cityId: number) => {
    return savedLocations.some((loc) => `${loc.latitude}-${loc.longitude}` === `${currentCity?.latitude}-${currentCity?.longitude}`);
  };

  return (
    <div className="relative w-full max-w-xl mx-auto z-50 px-4" ref={dropdownRef} id="city-search-container">
      <form onSubmit={handleSubmit} className="relative shadow-sm hover:shadow-md transition-shadow duration-300 rounded-full overflow-hidden bg-white/70 dark:bg-slate-900/60 backdrop-blur-xl border border-slate-200/50 dark:border-slate-800/100">
        <span className="absolute inset-y-0 left-4 flex items-center text-slate-400">
          <Search size={18} />
        </span>
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (e.target.value.length >= 2) {
              handleSearch(e.target.value);
            } else if (e.target.value.length === 0) {
              handleClear();
            }
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search for a city (e.g. Kyoto, Vancouver, Munich)..."
          className="w-full pl-11 pr-12 py-3.5 bg-transparent text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 text-sm focus:outline-none focus:ring-0 font-sans font-medium"
        />
        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute inset-y-0 right-4 flex items-center text-slate-400 hover:text-slate-600 transition"
          >
            <X size={18} />
          </button>
        )}
      </form>

      {/* Popover list of results */}
      {isOpen && (
        <div className="absolute top-full left-4 right-4 mt-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-2xl border border-slate-200/50 dark:border-slate-800/80 shadow-2xl overflow-hidden max-h-96 overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-200">
          {isSearching && (
            <div className="flex items-center justify-center py-6 text-slate-400 space-x-2">
              <Loader2 className="animate-spin" size={18} />
              <span className="text-xs font-mono">Searching coordinate indexes...</span>
            </div>
          )}

          {errorMessage && !isSearching && (
            <div className="py-4 px-5 text-sm text-amber-600 dark:text-amber-400 bg-amber-500/5 font-sans">
              {errorMessage}
            </div>
          )}

          {!isSearching && results.length > 0 && (
            <div className="py-1">
              <div className="px-4 py-2 text-[10px] uppercase font-bold tracking-wider text-slate-400 font-sans border-b border-slate-100/30 dark:border-slate-800/30">
                Search Results
              </div>
              {results.map((city) => (
                <button
                  key={city.id}
                  onClick={() => {
                    onSelectCity(city);
                    setQuery('');
                    setIsOpen(false);
                  }}
                  className="w-full text-left px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 flex justify-between items-center transition group"
                >
                  <div className="flex items-center space-x-3">
                    <MapPin size={16} className="text-slate-400 group-hover:text-blue-500 transition-colors" />
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 text-sm">{city.name}</span>
                      <p className="text-xs text-slate-400">
                        {city.admin1 ? `${city.admin1}, ` : ''}
                        {city.country}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs bg-slate-100 dark:bg-slate-850 text-slate-500 font-mono px-2 py-0.5 rounded uppercase">
                    {city.country_code}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Quick Select Popular Cities */}
          {!isSearching && results.length === 0 && (
            <div className="py-1">
              <div className="px-4 py-2 text-[10px] uppercase font-bold tracking-wider text-slate-400 font-sans border-b border-slate-100/30 dark:border-slate-800/30 flex justify-between items-center">
                <span>Quick Select Weather Hubs</span>
              </div>
              <div className="grid grid-cols-2 gap-1 p-2">
                {popularCities.map((city) => {
                  const isLocSaved = savedLocations.some(
                    (loc) => `${loc.latitude.toFixed(3)}-${loc.longitude.toFixed(3)}` === `${city.latitude.toFixed(3)}-${city.longitude.toFixed(3)}`
                  );
                  return (
                    <button
                      key={city.id}
                      onClick={() => {
                        onSelectCity({
                          id: Date.now() + Math.random(),
                          name: city.name,
                          country: city.country,
                          latitude: city.latitude,
                          longitude: city.longitude,
                          timezone: city.timezone,
                          country_code: city.id === 'london' ? 'GB' : city.id === 'new-york' ? 'US' : city.id === 'tokyo' ? 'JP' : city.id === 'sydney' ? 'AU' : 'FR',
                        });
                        setIsOpen(false);
                      }}
                      className="text-left p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/40 rounded-xl transition flex justify-between items-center border border-transparent hover:border-slate-100 dark:hover:border-slate-800/50"
                    >
                      <div>
                        <span className="font-medium text-slate-800 dark:text-slate-250 text-xs block">{city.name}</span>
                        <span className="text-[10px] text-slate-400 block truncate">{city.country}</span>
                      </div>
                      <MapPin size={12} className="text-slate-400" />
                    </button>
                  );
                })}
              </div>

              {/* Saved Locations */}
              {savedLocations.length > 0 && (
                <>
                  <div className="px-4 py-2 text-[10px] uppercase font-bold tracking-wider text-slate-400 font-sans border-t border-b border-slate-100/30 dark:border-slate-800/30 flex items-center space-x-1 mt-1">
                    <Star size={10} className="fill-amber-400 text-amber-400" />
                    <span>My Saved Locations ({savedLocations.length})</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-1 p-2">
                    {savedLocations.map((loc) => (
                      <button
                        key={loc.id}
                        onClick={() => {
                          onSelectCity({
                            id: Number(loc.id) || Date.now(),
                            name: loc.name,
                            country: loc.country,
                            latitude: loc.latitude,
                            longitude: loc.longitude,
                            timezone: loc.timezone,
                            country_code: '',
                            admin1: loc.admin1,
                          });
                          setIsOpen(false);
                        }}
                        className="text-left px-3 py-2 hover:bg-amber-500/5 dark:hover:bg-amber-500/5 rounded-xl transition flex justify-between items-center border border-transparent hover:border-amber-500/10 group"
                      >
                        <div className="truncate">
                          <span className="font-semibold text-slate-800 dark:text-slate-200 text-xs block truncate">{loc.name}</span>
                          <span className="text-[10px] text-slate-400 block truncate">{loc.admin1 || loc.country}</span>
                        </div>
                        <Star size={12} className="text-amber-400 fill-amber-400" />
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
