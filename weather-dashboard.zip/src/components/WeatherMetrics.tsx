/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Thermometer,
  Droplets,
  Wind,
  Compass,
  Cloudy,
  Gauge,
  Sun,
  Sunrise,
  Sunset,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { CurrentWeatherData, DailyWeatherData, UnitType } from '../types';
import { getWindDirection, getUvIndexDescription } from '../utils/weatherHelpers';

interface WeatherMetricsProps {
  current: CurrentWeatherData;
  daily: DailyWeatherData;
  unit: UnitType;
}

export default function WeatherMetrics({ current, daily, unit }: WeatherMetricsProps) {
  const tempUnit = unit === 'celsius' ? '°C' : '°F';
  
  // Calculate relative humidity feel text
  const getHumidityText = (h: number) => {
    if (h < 30) return { label: 'Dry Air', color: 'text-amber-500 bg-amber-500/10' };
    if (h <= 60) return { label: 'Comfortable', color: 'text-emerald-500 bg-emerald-500/10' };
    return { label: 'Humid/Sticky', color: 'text-blue-500 bg-blue-500/10' };
  };

  // Cloud cover details text
  const getCloudText = (c: number) => {
    if (c < 10) return 'Completely Clear';
    if (c < 30) return 'Mostly Clear';
    if (c < 70) return 'Partly Cloudy';
    return 'Overcast';
  };

  // Apparent temp vs actual temp text
  const tempDiff = current.apparent_temperature - current.temperature_2m;
  const getApparentDiffText = () => {
    if (Math.abs(tempDiff) < 1) return 'Feels similar to the actual temperature.';
    if (tempDiff > 0) return `Feels warmer by ${tempDiff.toFixed(1)}${tempUnit} due to humidity.`;
    return `Feels cooler by ${Math.abs(tempDiff).toFixed(1)}${tempUnit} due to windchill.`;
  };

  const humidityInfo = getHumidityText(current.relative_humidity_2m);
  const uvIndex = daily.uv_index_max[0] ?? 0;
  const uvInfo = getUvIndexDescription(uvIndex);

  // Pressure text
  const getPressureText = (hPa: number) => {
    if (hPa < 1009) return 'Low Pressure (Storm prone)';
    if (hPa <= 1020) return 'Normal Pressure (Stable)';
    return 'High Pressure (Clear weather)';
  };

  // Sunrise/sunset formatting
  const formatTimeStr = (isoStr: string) => {
    if (!isoStr) return '--:--';
    try {
      const date = new Date(isoStr);
      return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    } catch {
      return '--:--';
    }
  };

  const sunriseTime = daily.sunrise[0] ? formatTimeStr(daily.sunrise[0]) : '';
  const sunsetTime = daily.sunset[0] ? formatTimeStr(daily.sunset[0]) : '';

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5" id="weather-bento-grid">
      {/* 1. Real Feel Component */}
      <div 
        id="metric-real-feel"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Feels Like</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              {current.apparent_temperature.toFixed(1)}{tempUnit}
            </span>
          </div>
          <div className="p-3 bg-amber-500/10 rounded-2xl text-amber-500">
            <Thermometer size={20} />
          </div>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-4 leading-relaxed font-sans font-medium">
          {getApparentDiffText()}
        </p>
      </div>

      {/* 2. Humidity Component */}
      <div 
        id="metric-humidity"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Humidity</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              {current.relative_humidity_2m}%
            </span>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500">
            <Droplets size={20} />
          </div>
        </div>

        {/* Progress Bar Gauge */}
        <div className="mt-4 pt-1">
          <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div 
              style={{ width: `${current.relative_humidity_2m}%` }} 
              className="bg-blue-500 h-full rounded-full transition-all duration-500"
            />
          </div>
          <div className="flex justify-between items-center mt-3">
            <span className="text-[10px] text-slate-400 font-mono">0%</span>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${humidityInfo.color}`}>
              {humidityInfo.label}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">100%</span>
          </div>
        </div>
      </div>

      {/* 3. Wind speed & direction Component */}
      <div 
        id="metric-wind"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Wind Velocity</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              {current.wind_speed_10m.toFixed(1)} <span className="text-sm font-normal text-slate-400 dark:text-slate-500">km/h</span>
            </span>
          </div>
          <div className="p-3 bg-teal-500/10 rounded-2xl text-teal-500">
            <Wind size={20} />
          </div>
        </div>

        <div className="flex items-center space-x-3.5 mt-4">
          {/* Compass Icon Pointer */}
          <div className="relative w-10 h-10 rounded-full border-2 border-dashed border-slate-300 dark:border-slate-800 flex items-center justify-center bg-slate-50/50 dark:bg-slate-900/10">
            <Compass 
              size={18} 
              className="text-slate-500 dark:text-slate-400 transition-transform duration-700" 
              style={{ transform: `rotate(${current.wind_direction_10m}deg)` }}
            />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              Blows from {getWindDirection(current.wind_direction_10m)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">{current.wind_direction_10m}° Vector Coordinates</span>
          </div>
        </div>
      </div>

      {/* 4. UV Index Component */}
      <div 
        id="metric-uv-index"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">UV Index</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              {uvIndex} <span className="text-sm font-normal text-slate-400 dark:text-slate-500">of 12</span>
            </span>
          </div>
          <div className="p-3 bg-orange-500/10 rounded-2xl text-orange-500">
            <Sun size={20} />
          </div>
        </div>

        <div className="mt-4 pt-1">
          <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div 
              style={{ width: `${Math.min(100, (uvIndex / 12) * 100)}%` }} 
              className="bg-orange-500 h-full rounded-full transition-all duration-500"
            />
          </div>
          <div className="flex justify-between items-center mt-3">
            <span className="text-[10px] text-slate-400 font-mono">Index 0</span>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${uvInfo.color}`}>
              {uvInfo.label}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Index 12+</span>
          </div>
        </div>
      </div>

      {/* 5. Barometric Pressure Component */}
      <div 
        id="metric-pressure"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Air Pressure</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              {current.pressure_msl.toFixed(0)} <span className="text-sm font-normal text-slate-400 dark:text-slate-500">hPa</span>
            </span>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-2xl text-purple-500">
            <Gauge size={20} />
          </div>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-4 leading-relaxed font-sans font-medium">
          {getPressureText(current.pressure_msl)} — stable sea level pressure.
        </p>
      </div>

      {/* 6. Sunrise & Sunset Component */}
      <div 
        id="metric-sunrise-sunset"
        className="rounded-3xl p-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Celestial Cycle</span>
            <span className="text-3xl font-extrabold tracking-tight text-slate-850 dark:text-slate-100 mt-1 block">
              Solar Bounds
            </span>
          </div>
          <div className="p-3 bg-sky-500/10 rounded-2xl text-sky-500">
            <Sunrise size={20} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4 border-t border-slate-200/20 dark:border-slate-800/40 pt-4">
          <div className="flex items-center space-x-2">
            <div className="text-amber-500">
              <Sunrise size={16} />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Sunrise</span>
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">{sunriseTime}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-indigo-400">
              <Sunset size={16} />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Sunset</span>
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">{sunsetTime}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
