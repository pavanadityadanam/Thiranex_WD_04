/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Droplets, Clock, Thermometer } from 'lucide-react';
import { HourlyWeatherData, UnitType } from '../types';
import { getWeatherCondition, formatHour } from '../utils/weatherHelpers';

interface HourlyForecastProps {
  hourly: HourlyWeatherData;
  unit: UnitType;
  timezone: string;
}

export default function HourlyForecast({ hourly, unit, timezone }: HourlyForecastProps) {
  const tempUnit = unit === 'celsius' ? '°C' : '°F';
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  // Filter 24 hours starting from the current hour of the location's timezone or current time
  const getNext24Hours = () => {
    try {
      const now = new Date();
      // Try to determine which index in the hourly array is closest to the current hour
      let startIndex = 0;
      
      const currentTimeString = now.toISOString().split('T')[0] + 'T' + String(now.getHours()).padStart(2, '0') + ':00';
      const foundIndex = hourly.time.findIndex((t) => t.startsWith(currentTimeString));
      
      if (foundIndex !== -1) {
        startIndex = foundIndex;
      } else {
        // Fallback: see if we can find any time matches for the current day
        const todayStr = now.toISOString().split('T')[0];
        const todayIndex = hourly.time.findIndex((t) => t.startsWith(todayStr));
        if (todayIndex !== -1) {
          startIndex = todayIndex;
        }
      }

      // Slice 24 items
      const times = hourly.time.slice(startIndex, startIndex + 24);
      const temps = hourly.temperature_2m.slice(startIndex, startIndex + 24);
      const hums = hourly.relative_humidity_2m.slice(startIndex, startIndex + 24);
      const codes = hourly.weather_code.slice(startIndex, startIndex + 24);
      const rainProbs = hourly.precipitation_probability.slice(startIndex, startIndex + 24);

      return times.map((time, idx) => ({
        time,
        temp: temps[idx] ?? 0,
        humidity: hums[idx] ?? 0,
        code: codes[idx] ?? 0,
        rainProb: rainProbs[idx] ?? 0,
        formattedTime: formatHour(time),
      }));
    } catch {
      // Fallback
      return [];
    }
  };

  const hoursData = getNext24Hours();
  const selectedHour = hoursData[selectedIndex] || hoursData[0];

  if (hoursData.length === 0) {
    return null;
  }

  // Find min and max temp in this 24h slice for coordinate scaling
  const tempsOnly = hoursData.map((h) => h.temp);
  const maxTemp = Math.max(...tempsOnly);
  const minTemp = Math.min(...tempsOnly);
  const tempRange = maxTemp - minTemp || 1;

  // Render variables for custom responsive SVG Area Chart
  const svgWidth = 720;
  const svgHeight = 160;
  const paddingY = 25;
  const paddingX = 30;

  // Generate points coordinates for the temperature line
  const points = hoursData.map((item, index) => {
    const x = paddingX + (index * (svgWidth - paddingX * 2)) / (hoursData.length - 1);
    // Inverse scale temp: highest temp has lowest y value
    const relativeY = (item.temp - minTemp) / tempRange;
    const y = svgHeight - paddingY - relativeY * (svgHeight - paddingY * 2);
    return { x, y, item, originalIndex: index };
  });

  const linePath = points.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1]?.x ?? svgWidth} ${svgHeight - 10} L ${points[0]?.x ?? 0} ${svgHeight - 10} Z`;

  // Selected weather specifics
  const selectedCondition = selectedHour ? getWeatherCondition(selectedHour.code, true) : null;
  const SelectedIcon = selectedCondition ? selectedCondition.icon : null;

  return (
    <div 
      id="hourly-forecast-container"
      className="rounded-3xl p-6 md:p-8 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-850 dark:text-slate-100 flex items-center space-x-2">
            <span>24-Hour Immersive Forecasting</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Tap or hover over the hourly chart below to analyze specific timelines
          </p>
        </div>

        {/* Selected hour interactive detail bubble */}
        {selectedHour && selectedCondition && SelectedIcon && (
          <div className="flex items-center space-x-3.5 bg-white/65 dark:bg-slate-900/60 backdrop-blur-xl border border-slate-200/40 dark:border-slate-850/60 px-4 py-2 rounded-2xl shadow-sm transition">
            <div className={`p-2 rounded-xl ${selectedCondition.themeClass}`}>
              <SelectedIcon size={18} className={selectedCondition.iconColor} />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-mono">
                At {selectedHour.formattedTime}
              </span>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                  {selectedHour.temp.toFixed(1)}{tempUnit}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-300">
                  ({selectedCondition.label})
                </span>
                {selectedHour.rainProb > 0 && (
                  <span className="text-xs text-blue-500 font-bold flex items-center">
                    <Droplets size={10} className="mr-0.5" />
                    {selectedHour.rainProb}%
                  </span>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SVG Interactive Chart Box */}
      <div className="overflow-x-auto select-none mt-4 -mx-2 pb-3">
        <div style={{ minWidth: `${svgWidth}px` }} className="relative">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto overflow-visible">
            <defs>
              {/* Soft gradient fill under temperature line */}
              <linearGradient id="hourTempGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
              </linearGradient>
              <linearGradient id="lineAccentGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#60a5fa" />
                <stop offset="50%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#3b82f6" />
              </linearGradient>
            </defs>

            {/* Grid Lines */}
            <line x1={paddingX} y1={paddingY} x2={svgWidth - paddingX} y2={paddingY} className="stroke-slate-200/50 dark:stroke-slate-850/50" strokeWidth={1} strokeDasharray="3 3" />
            <line x1={paddingX} y1={svgHeight / 2} x2={svgWidth - paddingX} y2={svgHeight / 2} className="stroke-slate-200/30 dark:stroke-slate-850/30" strokeWidth={1} strokeDasharray="3 3" />
            <line x1={paddingX} y1={svgHeight - paddingY} x2={svgWidth - paddingX} y2={svgHeight - paddingY} className="stroke-slate-200/50 dark:stroke-slate-850/50" strokeWidth={1} strokeDasharray="3 3" />

            {/* Shaded Area */}
            <path d={areaPath} fill="url(#hourTempGrad)" />

            {/* Connecting Stroke Line */}
            <path 
              d={linePath} 
              fill="none" 
              stroke="url(#lineAccentGrad)" 
              strokeWidth={3} 
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Hover Guides and Interactive Dot Handles */}
            {points.map((p) => {
              const isSelected = p.originalIndex === selectedIndex;
              return (
                <g key={p.originalIndex} className="cursor-pointer">
                  {/* Invisible broad hitbox for easy touch targeting */}
                  <rect
                    x={p.x - 12}
                    y={0}
                    width={24}
                    height={svgHeight}
                    fill="transparent"
                    onMouseEnter={() => setSelectedIndex(p.originalIndex)}
                    onClick={() => setSelectedIndex(p.originalIndex)}
                  />

                  {/* Guide vertical bar */}
                  {isSelected && (
                    <line
                      x1={p.x}
                      y1={paddingY}
                      x2={p.x}
                      y2={svgHeight - paddingY}
                      className="stroke-blue-400 dark:stroke-blue-500"
                      strokeWidth={1.5}
                      strokeDasharray="2 2"
                    />
                  )}

                  {/* Dot anchors */}
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={isSelected ? 6 : 3}
                    className={`${
                      isSelected 
                        ? 'fill-blue-500 stroke-white dark:stroke-slate-900 stroke-2' 
                        : 'fill-slate-400 dark:fill-slate-600 hover:fill-blue-400'
                    } transition-all duration-150`}
                  />
                </g>
              );
            })}
          </svg>

          {/* Sliced Timeline Grid Labels beneath the SVG */}
          <div className="flex justify-between px-[30px] mt-2 border-t border-slate-200/10 dark:border-slate-800/10 pt-2">
            {hoursData.map((item, index) => {
              // Only draw every 4 hours to keep typography neat
              const shouldLabel = index % 4 === 0 || index === hoursData.length - 1;
              return (
                <span 
                  key={item.time}
                  className={`text-[10px] font-mono select-none w-8 text-center transition-colors ${
                    index === selectedIndex 
                      ? 'text-blue-500 font-extrabold' 
                      : 'text-slate-400'
                  }`}
                  style={{ visibility: shouldLabel ? 'visible' : 'hidden' }}
                >
                  {item.formattedTime.replaceAll(' ', '')}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
