/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Droplets } from 'lucide-react';
import { DailyWeatherData, UnitType } from '../types';
import { getWeatherCondition, formatDayName, formatDate } from '../utils/weatherHelpers';

interface DailyForecastProps {
  daily: DailyWeatherData;
  unit: UnitType;
}

export default function DailyForecast({ daily, unit }: DailyForecastProps) {
  const tempUnit = unit === 'celsius' ? '°C' : '°F';
  
  // Parse weather details for all 7 days
  const forecastDays = daily.time.map((timeStr, index) => {
    const code = daily.weather_code[index] ?? 0;
    const maxTemp = daily.temperature_2m_max[index] ?? 0;
    const minTemp = daily.temperature_2m_min[index] ?? 0;
    const rainProb = daily.precipitation_probability_max[index] ?? 0;
    const condition = getWeatherCondition(code, true);

    return {
      dateStr: timeStr,
      dayLabel: formatDayName(timeStr),
      fullDateLabel: formatDate(timeStr),
      maxTemp,
      minTemp,
      rainProb,
      condition,
    };
  });

  // Calculate global min and max temperature across all 7 days to size the temperature bars correctly
  const allMaxTemps = forecastDays.map((d) => d.maxTemp);
  const allMinTemps = forecastDays.map((d) => d.minTemp);
  const globalMax = Math.max(...allMaxTemps);
  const globalMin = Math.min(...allMinTemps);
  const globalRange = globalMax - globalMin || 1;

  return (
    <div 
      id="daily-forecast"
      className="rounded-3xl p-6 md:p-8 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 shadow-md hover:shadow-lg transition-all duration-300"
    >
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-850 dark:text-slate-100 flex items-center space-x-2">
            <span>7-Day Extended Forecast</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">Daily parameters based on localized forecasts</p>
        </div>
      </div>

      <div className="space-y-4">
        {forecastDays.map((day, idx) => {
          const Icon = day.condition.icon;
          // Calculate percentage offsets for the custom temperature slider indicator bar
          const leftOffsetPercent = ((day.minTemp - globalMin) / globalRange) * 100;
          const widthPercent = ((day.maxTemp - day.minTemp) / globalRange) * 100;

          return (
            <div 
              key={day.dateStr}
              className="grid grid-cols-1 sm:grid-cols-12 items-center gap-3 sm:gap-4 py-3 border-b border-slate-200/20 dark:border-slate-800/20 last:border-0 hover:bg-slate-900/5 dark:hover:bg-washed dark:hover:bg-white/5 rounded-xl px-2.5 transition duration-200"
            >
              {/* Day Name */}
              <div className="sm:col-span-3">
                <span className="font-bold text-slate-800 dark:text-slate-100 text-sm block">
                  {day.dayLabel}
                </span>
                <span className="text-[10px] text-slate-400 block font-medium">
                  {day.fullDateLabel.split(', ')[1]}
                </span>
              </div>

              {/* Weather Condition Icon & Label */}
              <div className="sm:col-span-4 flex items-center space-x-3">
                <div className={`p-1.5 rounded-lg ${day.condition.themeClass} flex-shrink-0`}>
                  <Icon size={18} className={day.condition.iconColor} />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block sm:truncate">
                    {day.condition.label}
                  </span>
                  {day.rainProb > 0 && (
                    <span className="text-[10px] text-blue-500 font-bold flex items-center mt-0.5">
                      <Droplets size={10} className="mr-0.5 fill-blue-500/20 text-blue-400" />
                      {day.rainProb}% Rain Risk
                    </span>
                  )}
                </div>
              </div>

              {/* Temperature Spread Bar */}
              <div className="sm:col-span-5 flex items-center space-x-3.5 mt-2 sm:mt-0">
                <span className="text-xs font-mono text-slate-400 dark:text-slate-500 w-8 text-right font-semibold">
                  {day.minTemp.toFixed(0)}{tempUnit}
                </span>
                
                {/* Visual spread gauge bar */}
                <div className="flex-1 bg-slate-200/50 dark:bg-slate-800/80 h-1.5 rounded-full relative overflow-hidden">
                  <div 
                    style={{ 
                      left: `${leftOffsetPercent}%`, 
                      width: `${Math.max(8, widthPercent)}%` 
                    }}
                    className="absolute top-0 bottom-0 bg-gradient-to-r from-blue-400 via-amber-400 to-orange-400 rounded-full"
                  />
                </div>

                <span className="text-xs font-mono text-slate-800 dark:text-slate-200 w-8 font-semibold">
                  {day.maxTemp.toFixed(0)}{tempUnit}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
