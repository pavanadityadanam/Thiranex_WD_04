/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CloudSun, 
  MapPin, 
  Navigation, 
  Search, 
  RotateCcw, 
  Star, 
  Info, 
  Sun, 
  Moon,
  CloudRain,
  Snowflake,
  Wind
} from 'lucide-react';

import { GeocodingResult, WeatherResponse, UnitType, SavedLocation } from './types';
import { getWeatherCondition, formatDate } from './utils/weatherHelpers';

// Subcomponents
import CitySearch from './components/CitySearch';
import WeatherMetrics from './components/WeatherMetrics';
import HourlyForecast from './components/HourlyForecast';
import DailyForecast from './components/DailyForecast';

export default function App() {
  const [currentCity, setCurrentCity] = useState<GeocodingResult>({
    id: 1,
    name: 'London',
    country: 'United Kingdom',
    latitude: 51.50853,
    longitude: -0.12574,
    country_code: 'GB',
    timezone: 'Europe/London',
  });

  const [unit, setUnit] = useState<UnitType>('celsius');
  const [weatherData, setWeatherData] = useState<WeatherResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>([]);

  // Load bookmarked cities from localStorage
  useEffect(() => {
    try {
      const persisted = localStorage.getItem('sky_saved_locations');
      if (persisted) {
        setSavedLocations(JSON.parse(persisted));
      } else {
        // Seed default popular bookmark list for easy exploration
        const seed: SavedLocation[] = [
          { id: 'london', name: 'London', country: 'United Kingdom', latitude: 51.50853, longitude: -0.12574, timezone: 'Europe/London' },
          { id: 'new-york', name: 'New York', country: 'United States', latitude: 40.71427, longitude: -74.00597, timezone: 'America/New_York' },
          { id: 'tokyo', name: 'Tokyo', country: 'Japan', latitude: 35.6895, longitude: 139.69171, timezone: 'Asia/Tokyo' },
        ];
        localStorage.setItem('sky_saved_locations', JSON.stringify(seed));
        setSavedLocations(seed);
      }
    } catch {
      // Graceful fallback if block storage unavailable
    }
  }, []);

  // Fetch Weather Forecast API
  const fetchWeather = async (city: GeocodingResult, activeUnit: UnitType) => {
    setIsLoading(true);
    setError(null);

    try {
      let endpoint = `https://api.open-meteo.com/v1/forecast?latitude=${city.latitude}&longitude=${city.longitude}` +
        `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m` +
        `&hourly=temperature_2m,relative_humidity_2m,weather_code,precipitation_probability` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max` +
        `&timezone=auto`;

      if (activeUnit === 'fahrenheit') {
        endpoint += '&temperature_unit=fahrenheit&wind_speed_unit=mph';
      }

      const response = await fetch(endpoint);

      if (!response.ok) {
        throw new Error('We encountered an issue checking the forecast database. Please check your network connection.');
      }

      const data: WeatherResponse = await response.json();
      
      if (!data.current || !data.daily || !data.hourly) {
        throw new Error('The weather registry returned partial parameters. Please re-enter city search.');
      }

      setWeatherData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred while communicating with REST service.');
    } finally {
      setIsLoading(false);
    }
  };

  // Trigger load when city or unit changes
  useEffect(() => {
    fetchWeather(currentCity, unit);
  }, [currentCity, unit]);

  // Bookmark active city
  const handleToggleSaveLocation = () => {
    let updated: SavedLocation[];
    const key = `${currentCity.latitude.toFixed(3)}-${currentCity.longitude.toFixed(3)}`;
    const alreadySaved = savedLocations.some((loc) => `${loc.latitude.toFixed(3)}-${loc.longitude.toFixed(3)}` === key);

    if (alreadySaved) {
      updated = savedLocations.filter((loc) => `${loc.latitude.toFixed(3)}-${loc.longitude.toFixed(3)}` !== key);
    } else {
      const fresh: SavedLocation = {
        id: String(Date.now()),
        name: currentCity.name,
        country: currentCity.country,
        latitude: currentCity.latitude,
        longitude: currentCity.longitude,
        admin1: currentCity.admin1,
        timezone: currentCity.timezone,
      };
      updated = [...savedLocations, fresh];
    }

    setSavedLocations(updated);
    try {
      localStorage.setItem('sky_saved_locations', JSON.stringify(updated));
    } catch {
      // Fail-silent
    }
  };

  const isCurrentCitySaved = savedLocations.some(
    (loc) => `${loc.latitude.toFixed(3)}-${loc.longitude.toFixed(3)}` === `${currentCity.latitude.toFixed(3)}-${currentCity.longitude.toFixed(3)}`
  );

  // Weather condition styling parameters
  const condition = weatherData 
    ? getWeatherCondition(weatherData.current.weather_code, weatherData.current.is_day === 1) 
    : getWeatherCondition(0, true);

  const CurrentIcon = condition.icon;

  return (
    <div 
      className={`min-h-screen transition-all duration-1000 bg-gradient-to-br ${condition.bgGradient} text-slate-800 dark:text-slate-100 pb-16 font-sans antialiased`}
      id="root-weather-view"
    >
      {/* 1. Header Navigation Bar */}
      <header className="max-w-7xl mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/10 dark:border-slate-800/10">
        <div className="flex items-center space-x-3" id="header-brand">
          <div className="p-2.5 bg-white/70 dark:bg-slate-900/60 rounded-2xl shadow-sm backdrop-blur-md">
            <CloudSun className="text-blue-500" size={24} />
          </div>
          <div>
            <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white uppercase font-sans">AETHER</span>
            <span className="text-[10px] font-mono block text-slate-400 font-bold tracking-wider -mt-1">Forecast Terminal</span>
          </div>
        </div>

        {/* Units / Imperial conversion toggler */}
        <div className="flex items-center space-x-3.5" id="unit-selectors">
          {/* Imperial metric switch */}
          <div className="flex bg-white/50 dark:bg-slate-900/40 p-1.5 rounded-full backdrop-blur-md border border-white/40 dark:border-slate-850/40">
            <button
              onClick={() => setUnit('celsius')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all duration-300 ${
                unit === 'celsius'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-450 hover:text-slate-705'
              }`}
            >
              Metric (°C)
            </button>
            <button
              onClick={() => setUnit('fahrenheit')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all duration-300 ${
                unit === 'fahrenheit'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-450 hover:text-slate-705'
              }`}
            >
              Imperial (°F)
            </button>
          </div>
        </div>
      </header>

      {/* 2. Main Search Bar */}
      <div className="py-6 sm:py-8">
        <CitySearch
          onSelectCity={setCurrentCity}
          savedLocations={savedLocations}
          onToggleSaveLocation={(loc) => {
            // Find and toggle
            setCurrentCity({
              id: Number(loc.id) || Date.now(),
              name: loc.name,
              country: loc.country,
              latitude: loc.latitude,
              longitude: loc.longitude,
              timezone: loc.timezone,
              country_code: '',
              admin1: loc.admin1,
            });
          }}
          currentCity={currentCity}
        />
      </div>

      {/* 3. Main Dashboard Frame */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6">
        <AnimatePresence mode="wait">
          {isLoading && (
            <motion.div
              key="loading-frame"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-24"
              id="loading-spinner-state"
            >
              <div className="relative w-16 h-16">
                <div className="absolute inset-0 rounded-full border-4 border-slate-200/50 dark:border-slate-800/100" />
                <div className="absolute inset-0 rounded-full border-4 border-blue-500 border-t-transparent animate-spin" />
              </div>
              <span className="text-sm font-mono mt-4 text-slate-400 font-bold uppercase tracking-widest animate-pulse">
                Parsing isobar atmospheric vectors...
              </span>
            </motion.div>
          )}

          {error && !isLoading && (
            <motion.div
              key="error-frame"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-xl mx-auto bg-white/70 dark:bg-slate-900/60 backdrop-blur-xl border border-red-200/85 dark:border-red-950/40 p-8 rounded-3xl shadow-xl text-center mt-12"
              id="error-handling-state"
            >
              <div className="w-16 h-16 bg-red-400/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-5">
                <Info size={30} />
              </div>
              <h3 className="text-lg font-bold text-slate-850 dark:text-red-300">Connection Interrupted</h3>
              <p className="text-sm text-slate-450 dark:text-slate-400 mt-2.5 leading-relaxed">
                {error}
              </p>
              <button
                onClick={() => fetchWeather(currentCity, unit)}
                className="mt-6 inline-flex items-center space-x-2 px-5 py-2.5 bg-slate-950 dark:bg-white text-white dark:text-slate-950 text-xs font-bold uppercase tracking-wider rounded-xl hover:shadow-lg hover:scale-102 transition"
              >
                <RotateCcw size={14} />
                <span>Re-establish Request</span>
              </button>
            </motion.div>
          )}

          {!isLoading && !error && weatherData && (
            <motion.div
              key="weather-content"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="space-y-6"
              id="dashboard-loaded-state"
            >
              {/* PRIMARY TOP PANEL: City Overview & Temperature display */}
              <div 
                id="main-overview-panel"
                className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-white/40 dark:border-slate-800/80 p-6 md:p-8 rounded-[36px] shadow-sm relative overflow-hidden"
              >
                {/* Background artistic bubble matching condition */}
                <div className={`absolute -right-16 -top-16 w-64 h-64 rounded-full blur-[80px] opacity-15 bg-gradient-to-br ${condition.themeClass}`} />

                {/* Left block: Location, Date & Temperature block */}
                <div className="md:col-span-7 flex flex-col justify-between space-y-6">
                  <div>
                    {/* Location tag with star bookmark status */}
                    <div className="flex items-center space-x-2.5">
                      <div className="flex items-center space-x-1.5 text-blue-500">
                        <MapPin size={16} />
                        <span className="text-xs font-bold uppercase tracking-wider font-mono">Real-time Node</span>
                      </div>
                      
                      <button
                        onClick={handleToggleSaveLocation}
                        className={`p-1.5 rounded-lg transition-transform hover:scale-110 flex items-center ${
                          isCurrentCitySaved 
                            ? 'text-amber-400' 
                            : 'text-slate-400 hover:text-amber-400'
                        }`}
                        title={isCurrentCitySaved ? 'Remove from bookmarked hubs' : 'Bookmark location'}
                      >
                        <Star size={16} className={isCurrentCitySaved ? 'fill-current' : ''} />
                      </button>
                    </div>

                    <h2 className="text-3xl md:text-5xl font-black tracking-tight text-slate-850 dark:text-white mt-2 leading-none flex items-baseline flex-wrap gap-x-2">
                      <span>{currentCity.name}</span>
                      <span className="text-lg md:text-xl font-medium text-slate-450 dark:text-slate-400 font-sans">
                        {currentCity.admin1 ? `${currentCity.admin1}, ` : ''}{currentCity.country}
                      </span>
                    </h2>
                    
                    <span className="text-xs text-slate-500 mt-2 block font-medium">
                      Current observations on {formatDate(new Date().toISOString())}
                    </span>
                  </div>

                  {/* Gigantic temperature display */}
                  <div className="flex items-baseline space-x-2">
                    <h1 className="text-7xl md:text-8xl font-black tracking-tighter text-slate-900 dark:text-white leading-none">
                      {weatherData.current.temperature_2m.toFixed(1)}
                    </h1>
                    <span className="text-3xl md:text-4xl font-extrabold text-slate-400 relative bottom-10">
                      {unit === 'celsius' ? '°C' : '°F'}
                    </span>
                  </div>

                  {/* Highlights overview indices */}
                  <div className="flex items-center space-x-4 border-t border-slate-200/20 dark:border-slate-800/20 pt-4">
                    <div className="text-xs">
                      <span className="text-slate-400 block font-mono text-[10px] uppercase font-bold tracking-wider">Absolute Low</span>
                      <span className="font-extrabold text-slate-800 dark:text-slate-200 text-sm font-mono mt-0.5 block">
                        {(weatherData.daily.temperature_2m_min[0] ?? 0).toFixed(0)}{unit === 'celsius' ? '°C' : '°F'}
                      </span>
                    </div>
                    <div className="h-6 w-px bg-slate-200/50 dark:bg-slate-800/40" />
                    <div className="text-xs">
                      <span className="text-slate-400 block font-mono text-[10px] uppercase font-bold tracking-wider">Absolute High</span>
                      <span className="font-extrabold text-slate-800 dark:text-slate-200 text-sm font-mono mt-0.5 block">
                        {(weatherData.daily.temperature_2m_max[0] ?? 0).toFixed(0)}{unit === 'celsius' ? '°C' : '°F'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right block: Giant gorgeous weather artwork status */}
                <div className="md:col-span-5 flex flex-col justify-center items-center py-5 md:py-0 border-t md:border-t-0 md:border-l border-slate-200/20 dark:border-slate-800/20">
                  <div className={`p-6 md:p-8 rounded-full ${condition.themeClass} relative group transition`}>
                    <CurrentIcon size={72} className={`${condition.iconColor} transition duration-500 transform group-hover:scale-105`} />
                  </div>
                  <span className="text-xl font-bold tracking-tight text-slate-850 dark:text-white mt-4 block">
                    {condition.label}
                  </span>
                  <span className="text-xs text-blue-500 font-bold block mt-1 font-mono uppercase tracking-wider">
                    Barometer: {weatherData.current.pressure_msl.toFixed(0)} hPa
                  </span>
                </div>
              </div>

              {/* SECOND ROW: 24-Hour interactive chart slider */}
              <HourlyForecast 
                hourly={weatherData.hourly} 
                unit={unit} 
                timezone={weatherData.timezone}
              />

              {/* THIRD ROW SECTION: Grid holding detailed metrics & daily calendar */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Bento layout detailed stats metrics */}
                <div className="lg:col-span-7 space-y-6">
                  <WeatherMetrics current={weatherData.current} daily={weatherData.daily} unit={unit} />
                </div>
                
                {/* 7 Day Extended forecast card list */}
                <div className="lg:col-span-5">
                  <DailyForecast daily={weatherData.daily} unit={unit} />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
